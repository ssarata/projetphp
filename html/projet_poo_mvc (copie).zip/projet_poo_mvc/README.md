sudo a2enmod rewrite
sudo systemctl restart apache2

apache2.conf
