<?php
 class BankAccount {
	
	public $accountNumber;
	public $balance;
	
	/*private $accountNumber;
	private $balance;*/
	
	
        

	
	
}
