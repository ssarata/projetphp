<?php
interface BankAccount{
	public function getAccountNumber();

	public function setAccountNumber($num);

	public function getbalance();

	public function setbalance($num);
	
	public function deposit($argent);
	public function withdraw($somme);
	public function transfer($objet1,int $montant);	


}
