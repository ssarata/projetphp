<?php
class SavingsAccount implements BankAccount{

private $accountNumber;
	private $balance;
    private $interestRate;
	
	public function __construct(int $x, int $y){
        $this->accountNumber = $x;
        $this->balance = $y;
    }
	
public function addInterest($interet){
        $this-> setinterestRate($interet);
       return $this->setbalance($this-> getbalance()+($this-> getbalance()*($this->getInterestRate()/100)));

    }
}