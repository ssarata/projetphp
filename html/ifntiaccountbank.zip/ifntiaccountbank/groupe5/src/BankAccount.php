<?php
interface BankAccount{
	public function getAccountNumber();
	public function getbalance();

	
}
